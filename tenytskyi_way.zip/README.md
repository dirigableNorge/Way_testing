# Путешествие по Европе

- [Техническое задание](https://www.notion.so/e6273f55c1b4458e96021b40bf1f37b5)

- [Instruction](https://www.notion.so/dc09afe5fc744ead8d9db523acf5dfde)
- [Project card](https://docs.google.com/spreadsheets/d/1gjC-qhyy2AV5I-Ap3xaY2V_RXCmV5XxotLOndLzFw_A/edit#gid=88910524)
- [Criteries](https://docs.google.com/spreadsheets/d/1DVPzo4dXUwYclahYVoQNrxpNGXQfvkq8MGMhgdhZwzI/edit#gid=787952136)

- [Библиотека полезных материалов](https://www.notion.so/4c251c569975483eae403776b76a0f87)
- [Справочник решений ver. 1](https://www.notion.so/ver-1-589143c4d7e84ac4a1a470c817e3d259)
- [Админка проектов](https://www.notion.so/b70bec4c36684360bc7e87b8f807cc7d)

Для полной сборки (с конвертацией графики) npm run build

Для работы с готовой графикой npm run dev-start
